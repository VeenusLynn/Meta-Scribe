import interactions
import os
import dotenv
from discord.ui import Select, View

dotenv.load_dotenv()

bot = interactions.Client(token=os.getenv('DISCORD_TOKEN'))

class LanguageView(View):
    def __init__(self):
        super().__init__()

        self.add_item(Select(
            placeholder='Select a language',
            options=[
                interactions.SelectOption(
                    label='English',
                    value='en'
                ),
                interactions.SelectOption(
                    label='Spanish',
                    value='es'
                ),
                interactions.SelectOption(
                    label='French',
                    value='fr'
                )
            ],
            custom_id='language_selection'
        ))

    async def interaction_check(self, interaction: interactions.Interaction):
        # Only allow interactions from the command author
        return interaction.user.id == self.message.reference.resolved.author.id

@bot.event
async def on_ready():
    print('Bot is ready')

@bot.command(
    name='hey',
    description='Ping pong',
    options=[
        interactions.Option(
            name="name",
            description="What you want to say",
            type=interactions.OptionType.STRING,
            required=True,
        ),
    ],
)
async def hey(ctx: interactions.CommandContext, name: str):
    await ctx.send(f'Pong!, {name}')

    # Create and send the language dropdown prompt
    language_view = LanguageView()
    await ctx.send('Please select a language:', view=language_view)

bot.start()
